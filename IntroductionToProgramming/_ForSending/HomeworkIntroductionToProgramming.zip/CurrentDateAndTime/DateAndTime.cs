﻿//Problem 14.	 Current Date and Time
//Create a console application that prints the current date and time.Find in Internet how.

using System;

class DateAndTime
{
    static void Main()
    {
        Console.WriteLine("The current date and time are:");
        Console.WriteLine(DateTime.Now);
        Console.WriteLine();
    }
}
